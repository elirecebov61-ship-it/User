import asyncio
import logging
from pyrogram import Client, idle
from config import Config

logging.basicConfig(level=logging.INFO)

app = Client(
    "userbot",
    api_id=Config.API_ID,
    api_hash=Config.API_HASH,
    session_string=Config.SESSION_STRING,
)

import plugins.addbot

async def main():
    await app.start()
    await idle()
    await app.stop()

if __name__ == "__main__":
    asyncio.run(main())
