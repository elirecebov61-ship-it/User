from pyrogram import Client, filters
from pyrogram.types import Message, ChatPrivileges
from main import app

@app.on_message(filters.command("addbot", prefixes=".") & filters.me)
async def add_bot(client: Client, message: Message):
    if len(message.command) < 2:
        await message.delete()
        return

    username = message.command[1].lstrip("@")

    try:
        await client.add_chat_members(message.chat.id, username)
        await client.promote_chat_member(
            message.chat.id,
            username,
            privileges=ChatPrivileges(
                can_manage_chat=True,
                can_delete_messages=True,
                can_manage_video_chats=True,
                can_restrict_members=True,
                can_promote_members=True,
                can_change_info=True,
                can_invite_users=True,
                can_pin_messages=True,
            )
        )
    except:
        pass

    await message.delete()
